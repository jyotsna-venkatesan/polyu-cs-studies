#include <iostream>

using namespace std;

int main() {

    cout << "Welcome to COMP1011!" << endl;

    return 0;

}