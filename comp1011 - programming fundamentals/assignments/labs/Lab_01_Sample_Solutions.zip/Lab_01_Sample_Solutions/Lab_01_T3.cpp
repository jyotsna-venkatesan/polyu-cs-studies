#include <iostream>

using namespace std;

int main()
{
	cout << "Dennis Liu" << endl;
	cout << "ywliu@polyu.edu.hk" << endl;

	return 0;
}

