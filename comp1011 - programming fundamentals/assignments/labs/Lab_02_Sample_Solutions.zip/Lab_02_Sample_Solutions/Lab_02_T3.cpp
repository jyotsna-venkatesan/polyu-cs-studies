#include <iostream>
#include <cmath>

using namespace std;

int main() {

    double x, orig_salary, output;

    cout << "What is your salary?";
    cin >> orig_salary;

    x = pow(1.05, 10);  // After 10 years
    output = orig_salary * x;

    cout << "After 10 years, your salary is: " << output << endl;

    return 0;
}