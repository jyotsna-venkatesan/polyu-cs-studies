#include <iostream>
using namespace std;

int main() {

    cout << "Hello there.\n";
    cout << "Here is 5: " << 5 << "\n";
    cout << "endl writes a new line to the screen.";
    cout << endl;
    cout << "Here is a very big number:\t" << 70000 << endl;
    cout << "Here is the sum of 8 and 5:\t" << 8 + 5 << endl;
    cout << "Here's a fraction:\t\t" << 5.0 / 8 << endl;
    cout << "And a very very big number:\t";
    cout << 7000 * 7000 << endl;
    cout << "I am a C++ programmer!\n";

    cout << "My name is " << "<your name>"  << " and my age is " << 20 << ".";

    return 0;
}